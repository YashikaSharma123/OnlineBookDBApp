package com.bookapp.main;

import com.bookapp.exceptions.IdNotFoundException;
import com.bookapp.model.Book;
import com.bookapp.service.BookService;
import com.bookapp.service.BookServiceImpl;

public class Admin {

	public static void main(String[] args) {

		//Book book = new Book("Java in Action",11,"Kath","Tech",900.0);
		//Book book1 = new Book("Java in Action",13,"Katha","Tech",800.0);
		//Book book2 = new Book("Java in Action",12,"Kathi","Tech",1900.0);
		BookService service = new BookServiceImpl();
		//service.addBook(book2);
		
		try {
			service.deleteBook(12);
		}catch(IdNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
		try {
			service.updateBook(11,12000);
		}catch(IdNotFoundException e) {
			System.out.println(e.getMessage());
		}
		
		
	}

}
